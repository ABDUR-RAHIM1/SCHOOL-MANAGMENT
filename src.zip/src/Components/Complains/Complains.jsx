import React, { useContext, useEffect, useState } from 'react'
import { AiFillCloseCircle } from "react-icons/ai"
import errorImg from "../../image/imgnotfound.PNG"
import "./Complain.css"
import Complain from './Complain'
import Loading from '../Loading/Loading';
import { GlobalContext } from '../../State/State'
function Complains() {
  const {getDate} = useContext(GlobalContext)
  const [complainData, setComplainData] = useState([]);
  const [detailsData, setDetailsData] = useState(null)
  const [detailsClick, setDetailsClick] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isDelete, setIsDelete] = useState(false)
  useEffect(() => {
    !isDelete && setIsLoading(true)
    fetch("http://localhost:8000/api/complain/")
      .then(res => res.json())
      .then(data => {
        console.log(data)
        setIsLoading(false)
        setComplainData(data)
      })
  }, [isDelete]);

  // delete compline
  const deleteComplined = (id) => {
    fetch(`http://localhost:8000/api/complain/${id}`, {
      method: "DELETE"
    }).then(res => res.json())
      .then(data => {
        console.log(data);
        setIsDelete(!isDelete)
      })
  }

  //  show details complain function,  pass data when details btn click or not
  const details = (complain) => {
    setDetailsClick(!detailsClick)
    setDetailsData(complain)
  }

  if (isLoading) {
    return <Loading />
  }
  return (
    <>

      <h2 className='text-center my-3 text-success'>Complaints</h2>
      <div className={detailsClick ? "complaints-container hide" : "complaints-container show"}>
        {
          complainData && complainData.slice().reverse().map(cData => (
            <Complain
              key={cData._id}
              complain={cData}
              deleteComplined={deleteComplined}
              details={details}
            />
          ))
        }
      </div>

      <div className={detailsClick ? "complains-details show" : "complains-details hide"}>
        <AiFillCloseCircle onClick={() => setDetailsClick(!detailsClick)} className="closeDetails" />
        {
          detailsData &&
          <div className="details">
            <div className="detailImg">
              <img src={detailsData.image || errorImg} alt="" />
            </div>
            <p className='text-primary'>complainant : {detailsData.name}</p>
            <p className='text-muted'>Email : {detailsData.email}</p>
            <small className='text-muted'>{getDate(detailsData.date)}</small>
            <h4 className='mt-3'>Subject : {detailsData.title}</h4>
            <p><span>Details</span> : {detailsData.desc}</p>
          </div>
        }
      </div>

    </>
  )
}

export default Complains