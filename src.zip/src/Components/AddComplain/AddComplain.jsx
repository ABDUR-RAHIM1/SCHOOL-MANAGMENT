import React, { useContext, useEffect, useState } from 'react'
import "./AddComplain.css"
import { GlobalContext } from '../../State/State'
function AddComplain() {
    const { complain, setComplain } = useContext(GlobalContext)
    const [isloading , setIsLoading] = useState(false)
    const  [message , setMessage] = useState("")
    const  [imgLoding , setImgLoading] = useState(false)

    const handleComplainChange = (e) => {
        setComplain({ ...complain, [e.target.name]: e.target.value })
    } 
    const handelImageChange = async (e) => {
        setImgLoading(true)
        const file = e.target.files[0]
        const formData = new FormData();
        formData.append("file", file);
        formData.append("upload_preset", "demo-image");
        formData.append("cloud_name", "dsrkrb3jy");
        const res = await fetch(
            "https://api.cloudinary.com/v1_1/dsrkrb3jy/image/upload",
            {
                method: "POST",
                body: formData,
            })
        const data = await res.json()
        setComplain((prevItem) => ({
            ...prevItem,
            image: data.url
        }))
        setImgLoading(false)
    } 

    //  add complain 
    const handleAddComplain = (e)=>{
     e.preventDefault();
     setIsLoading(true)
     fetch("http://localhost:8000/api/complain", {
        method :"POST",
        headers : {
            "Content-type" :"application/json"
        },
        body : JSON.stringify(complain)
     }).then(res => res.json())
     .then(data => {
         console.log(data);
         setIsLoading(false)
         data.error ? setMessage(data.error) : setMessage(data.message)

     })
    }

    //  add name of complainer
    useEffect(()=>{
         const data = localStorage.getItem("userInfo")
         if (data) {
             const user = JSON.parse(data)
            setComplain((preCom)=> ({
                 ...preCom,
                 name : user.name,
                 email : user.email
            }))
         }
    } ,[])
    console.log(complain)

    if (message) {
        setTimeout(() => {
            setMessage("")
        },3000);
    }
    return (
        <div className='addComplainContainer'>
            <form onSubmit={handleAddComplain} className='form-group form-control p-3'>
                <h3 className='my-2 text-success'>Complain Box</h3>
                <input type="text"
                    id='subject'
                    name='title'
                    className='form-control'
                    placeholder='Complain Subject'
                    required
                    value={complain.title}
                    onChange={handleComplainChange}
                />
                <small id="subject" className="form-text text-muted"> Write Complain Subject</small>

                <textarea
                    name="desc"
                    id='desc'
                    className='form-control mt-3'
                    placeholder='Write Your Complain'
                    required
                    value={complain.desc}
                    onChange={handleComplainChange}
                />
                <small id="desc" className="form-text text-muted"> Write Complain Subject</small>
                <input type="file"
                    className='form-control  my-3'
                    onChange={handelImageChange}
                />
                <small id="file" className="form-text text-muted"> 
                 {
                    imgLoding ? <span className='text-danger'>image Uploading . . .</span> : <span>upload Document</span>
                 }
                </small>  <br />
                <button disabled={imgLoding} className='btn fw-bold my-4 btn-outline-success'>
                    {isloading ? "processing" : "Submit complain"}</button>

                    {
                        message && <h6 className={message.includes("submit ") ? "text-center text-success" : "text-center text-danger"}>{message}</h6>
                    }
            </form>
        </div>
    )
}

export default AddComplain