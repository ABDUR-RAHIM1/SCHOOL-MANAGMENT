import React, { useContext, useState } from 'react'
import demoImg from "../../image/demo.jpg"
import { GlobalContext } from '../../State/State';
import {AiOutlineDelete} from "react-icons/ai" 
import { useLocation } from 'react-router-dom';
function Chat(props) {
    const [show , setShow] = useState(false)
    const {_id , message, messageType, reciverName, reciverPhoto, senderName, senderPhoto, timestamp } = props.chat;
    const { getDate } = useContext(GlobalContext)
    let img = null
    let styleName = null;
    let chatItem = null
    let name = null
    if (messageType === "sender") {
        img = senderPhoto
        styleName = "left"
        chatItem = "chatItem_right"
        name = senderName
    } else {
        img = reciverPhoto
        styleName = "right"
        chatItem = "chatItem_left"
        name = reciverName
    }
    const handleDleteShow = ()=>{
         setTimeout(() => {
            setShow(!show)
         }, 1500);
    }
    return (
        <div className={`${styleName} chatWrap`}>
            <div className={chatItem}>
                {show && 
                <AiOutlineDelete
                 onClick={()=>props.handleMessageDelete(_id)}
                 className="msgDeleteBtn"
                 />}
                <img className='chatImg' src={img || demoImg} alt="" />
                <div className="text">
                    <small className='chatName'>{name}</small>
                    <p onClick={handleDleteShow} className='chatMessage'>{message}</p>
                    <small className='chatDate'>{getDate(timestamp)}</small>
                </div>
            </div>
        </div>
    )
}

export default Chat