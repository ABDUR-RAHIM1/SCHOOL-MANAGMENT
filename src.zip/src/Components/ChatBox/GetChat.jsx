import React, { useContext, useEffect, useState } from 'react'
import Chat from './Chat';
import { GlobalContext } from '../../State/State';
import Loading from '../Loading/Loading';

function GetChat() {
    const  {isSuccessMessage} = useContext(GlobalContext) 
    const [isDelete, setIsDelete] = useState(false)
    const [chat , setChat] = useState([]);
    useEffect(()=>{
         fetch("http://localhost:8000/api/chat/")
         .then(res => res.json())
         .then(data => {
            console.log(data);
            setChat(data) 
         })
    } ,[setChat, isSuccessMessage, isDelete])
    //  handle delete

    const handleMessageDelete=(id)=>{ 
         fetch(`http://localhost:8000/api/chat/${id}`, {
            method :"DELETE",
         }).then(res => res.json())
         .then(data => {
            console.log(data)
            setIsDelete(!isDelete)
         })
    } 
    if(!chat && chat.length <= 0) return <Loading/>
  return (
    <div>
         {
            chat && chat.map(chat => (
                 <Chat
                  key={chat._id}
                  chat={chat}
                  handleMessageDelete={handleMessageDelete}
                 />
            ))
         }
    </div>
  )
}

export default GetChat