import React from 'react'

function Sender(props) {
   
  return (
    <div className='messageField flex_box'>
         <input 
         type={props.type} 
         name={props.name}
         placeholder={props.placeholder}
         className={props.className}
         onChange={props.handleMessage}
         required={props.required}
         value={props.value}
         />
         <button className='btn btn-danger'>Send</button>
    </div>
  )
}

export default Sender