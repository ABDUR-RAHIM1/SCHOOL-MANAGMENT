import React, { useContext } from 'react'
import { AiFillDelete } from "react-icons/ai"
import DemoImg from "../../image/demo.jpg"
import { GlobalContext } from '../../State/State';
function StProfile(props) {
  const { getDate } = useContext(GlobalContext)
  const { _id, name, email, image, date } = props.students;
  return (
    <div className='stProfile'>
      <div className={props.check ? "adminBtn" : "adminBtn hide"}>
        <AiFillDelete onClick={() => props.handleDeleteStudent(_id)} className='adminBtnIcon text-danger' />
      </div>
      <img src={image || DemoImg} alt="" />
      <div className='p-1'>
        <small className='text-muted'><span className='color'>Join:</span> {getDate(date)}</small>
        <p>Name : {name}</p>
        <p>Email : {email}</p>
      </div>
    </div>
  )
}

export default StProfile