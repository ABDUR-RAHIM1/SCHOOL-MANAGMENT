import React from 'react'
import "./Home.css"
import Hero from '../Hero/Hero'   
import Review from '../Review/Review'  
import TopStudents from '../TopStudents/TopStudents'
import Contact from '../Contact/Contact'
function Home() {

  return (
    <div className='homeContainer'>
        <Hero/> 
        <TopStudents/>
        <Review/> 
        <Contact/>
    </div>
  )
}

export default Home