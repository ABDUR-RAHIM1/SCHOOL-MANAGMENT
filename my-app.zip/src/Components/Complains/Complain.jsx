import React from 'react'
import { AiFillDelete } from "react-icons/ai"
import { BsFillArrowDownRightCircleFill } from "react-icons/bs"
import errorImg from "../../image/imgnotfound.PNG"
function Complain(props) {
    const { title, desc, image, _id } = props.complain;
    const text = 100;
    return (
        <div className='complain flex_box'>
            <div className="imgWrap">
                <AiFillDelete onClick={() => props.deleteComplined(_id)} className="deleteCompoIcon" />
                <img src={image || errorImg} alt="" />
            </div>
            <div className="textWrap">
                <h5><span className='text-danger'>Subject</span> : {title.length > 35 ? title.slice(0, 35)+ " . . ." : title}</h5>
                <p>Complain : {desc.length > text ? desc.slice(0, text) + ". . ." : desc}</p>
            </div>
            <BsFillArrowDownRightCircleFill
                onClick={() => props.details(props.complain)}
                title='Check it'
                className='arrowIcon'
            />
        </div>
    )
}

export default Complain