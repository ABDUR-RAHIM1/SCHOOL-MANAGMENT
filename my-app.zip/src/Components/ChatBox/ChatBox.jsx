import React, { useContext, useEffect, useState } from 'react'
import "./ChatBox.css" 
import tune from '../../media/tune.mp3'
import { GlobalContext } from '../../State/State'
import Sender from './Sender'
import GetChat from './GetChat'
import { useLocation } from 'react-router-dom'

function ChatBox() {
    const location = useLocation().pathname
    const [isSend, setIsSend] = useState(false) 
    const [imgLoading , setImgLoading]  = useState(false)
    const  {isSuccessMessage, setIsSuccessMessage, chatValue, setChatValue} = useContext(GlobalContext) 
    const handleMessage = (e) => {
        setChatValue({ ...chatValue, [e.target.name]: e.target.value })
    }

    //  upload image  

    const handelImageChange = async (e) => {
        setImgLoading(true)
        const file = e.target.files[0]
        const formData = new FormData();
        formData.append("file", file);
        formData.append("upload_preset", "demo-image");
        formData.append("cloud_name", "dsrkrb3jy");
        const res = await fetch(
            "https://api.cloudinary.com/v1_1/dsrkrb3jy/image/upload",
            {
                method: "POST",
                body: formData,
            })
        const data = await res.json()
        setChatValue((prevItem) => ({
            ...prevItem,
            image: data.url
        }))
        setImgLoading(false)
    }
console.log(chatValue)
    useEffect(() => {
        if (location === "/admin-dashboard") {
            const data = localStorage.getItem("adminInfo");
            const admin = JSON.parse(data)
            setChatValue((preData) => ({
                ...preData,
                reciverName: admin.name,
                reciverPhoto: admin.image,
                messageType: "receiver"
            }))
        }
        else {
            const data = localStorage.getItem("userInfo");
            if (data) {
                const user = JSON.parse(data);
                console.log(user)
                setChatValue((preData) => ({
                    ...preData,
                    senderName: user.name,
                    senderPhoto: user.image,
                    messageType: "sender"
                }))
            }
        }
    }, [setChatValue, location])
     
    //  message sender 
    const handleMessageSender = (e) => {
        e.preventDefault();
        console.log("message send")
        fetch("https://myschoool.onrender.com/api/chat/", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(chatValue)
        }).then(res => res.json())
            .then(data => {
                console.log(data)
                setChatValue((preData) => ({
                    ...preData, 
                    message :"",
                    image : ""
                }))
                setIsSend(true)
                setTimeout(() => {
                    setIsSend(false)
                }, 2000);
                setIsSuccessMessage(!isSuccessMessage)
            })
    }
    //  audio player
    useEffect(() => {
        const audioPlayer = document.getElementById('audioPlayer');
        if (isSend) {
          audioPlayer.play();
        } else {
          audioPlayer.pause();
          audioPlayer.currentTime = 0; 
        }
      }, [isSend]);
 
    return (
        <div className='chatBoxWrap'>
            
        <audio className='opacity-0 d-none' id="audioPlayer" src={tune} controls />
            <div className="chatHeader">
                <h6 className='text-center text-light bgColor p-2'>Group Chat</h6>
            </div>
            <div className='cahtbox'>

                <GetChat />

            </div>
            <form onSubmit={handleMessageSender}>
                <Sender
                    type="text"
                    name='message'
                    placeholder='Send Message'
                    className='form-control chatInput'
                    required="required"
                    value={chatValue.message}
                    handleMessage={handleMessage} 
                    handelImageChange={handelImageChange}
                    imgLoading={imgLoading}
                />
                {/* <button>SEND</button> */}
            </form>
        </div>
    )
}

export default ChatBox