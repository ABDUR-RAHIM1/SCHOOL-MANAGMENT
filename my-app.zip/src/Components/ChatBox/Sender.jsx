import React from 'react'
import Spinner from "../../Components/Spinner/Spinner"
import { BsCardImage } from "react-icons/bs"
import { AiOutlineSend } from "react-icons/ai"
function Sender(props) {

  return (
    <div className='messageField flex_box'>
      <input
        type={props.type}
        name={props.name}
        placeholder={props.placeholder}
        className={props.className}
        onChange={props.handleMessage}
        required={props.required}
        value={props.value}
      />
      <label htmlFor="file">
       { props.imgLoading ? <Spinner/> : <BsCardImage className="chatIcon" />}
      </label>
      <input onChange={props.handelImageChange} className='d-none' type="file" id='file' />
      <button disabled={props.imgLoading} className='sendBtn'>
        <AiOutlineSend className="chatIcon" />
      </button>
    </div>
  )
}

export default Sender