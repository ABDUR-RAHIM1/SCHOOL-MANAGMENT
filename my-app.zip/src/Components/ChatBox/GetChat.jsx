import React, { useContext, useEffect, useState } from 'react'
import Chat from './Chat';
import { GlobalContext } from '../../State/State';
import Loading from '../Loading/Loading';

function GetChat() {
    const  {isSuccessMessage} = useContext(GlobalContext) 
    const [message , setMessage] =  useState("")
    const [loading , setLoading] = useState(false)
    const [isDelete, setIsDelete] = useState(false)
    const [chat , setChat] = useState([]);
    useEffect(()=>{
      message ?setLoading(false) : setLoading(true)
      
         fetch("https://myschoool.onrender.com/api/chat/")
         .then(res => res.json())
         .then(data => { 
            setChat(data) 
            console.log(data)
            setMessage("Message")
            setLoading(false)
         })
    } ,[setChat, isSuccessMessage, isDelete])
console.log(message)
    //  handle delete 
    const handleMessageDelete=(id)=>{ 
         fetch(`https://myschoool.onrender.com/api/chat/${id}`, {
            method :"DELETE",
         }).then(res => res.json())
         .then(data => {
            console.log(data)
           setMessage(data.message)
            setIsDelete(!isDelete)
         })
    } ;

    if(loading) return <Loading/>

  return (
    <div>
         {
            chat && chat.map(chat => (
                 <Chat
                  key={chat._id}
                  chat={chat}
                  handleMessageDelete={handleMessageDelete}
                 />
            ))
         }
    </div>
  )
}

export default GetChat