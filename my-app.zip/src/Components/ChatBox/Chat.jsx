import React, { useContext, useState } from 'react'
import demoImg from "../../image/demo.jpg"
import { GlobalContext } from '../../State/State';
import { AiOutlineDelete } from "react-icons/ai"
import { useLocation } from 'react-router-dom';
function Chat(props) {
    const [show, setShow] = useState(false)
    const { _id, message, messageType, reciverName, reciverPhoto, senderName, senderPhoto, image, timestamp } = props.chat;
    const { getDate } = useContext(GlobalContext)
    let img = null
    let styleName = null;
    let textBg = null;
    let chatItem = null
    let name = null
    if (messageType === "sender") {
        img = senderPhoto
        styleName = "left"
        textBg = "text2"
        chatItem = "chatItem_right"
        name = senderName
    } else {
        img = reciverPhoto
        styleName = "right"
        textBg = "text"
        chatItem = "chatItem_left"
        name = reciverName
    }
    const handleDleteShow = () => {
        setTimeout(() => {
            setShow(!show)
        }, 1500);
    }
    return (
        <div onClick={handleDleteShow} className={`${styleName} chatWrap`}>
            <div className={chatItem}>
                {show &&
                    <AiOutlineDelete
                        onClick={() => props.handleMessageDelete(_id)}
                        className="msgDeleteBtn"
                    />}
                <img className='chatImg' src={img || demoImg} alt="" />
                <div className={textBg}>
                    <small className='chatName'>{name}</small>
                    <p className='chatMessage'>{message}</p>
                  { image &&   <div className='text-center'>
                     <img className={image && 'sendImg'} src={image} alt="" />
                     </div>}
                    <small className='chatDate'>{getDate(timestamp)}</small>
                </div>
            </div>
        </div>
    )
}

export default Chat