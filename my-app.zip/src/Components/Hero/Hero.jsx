import React, { useContext, useEffect, useState } from 'react' 
import "./Hero.css"
import AOS from 'aos';
import 'aos/dist/aos.css';
import { GlobalContext } from '../../State/State';
import HeroText from '../HeroText/HeroText';
import Loading from '../Loading/Loading';
function Hero() {
  const [isLoading, setIsLoading] = useState(false)
  const { heroContent, setHeroContent} = useContext(GlobalContext)

  //  animation 
  useEffect(() => {
    AOS.init({ 
    });
  }, []);

  // get hero content data 
  useEffect(() => {
    setIsLoading(true)
    fetch("https://myschoool.onrender.com/api/settings/hero")
      .then(res => res.json())
      .then(data => {
        setHeroContent(data.hero)
        setIsLoading(false)
      
      })
  }, [setHeroContent])
  if(isLoading) return <Loading/>
  return (
    <div className='hero_container flex_box' data-aos="fade-up" >

      {
        heroContent && heroContent.map(hero => <HeroText
          key={hero._id}
          hero={hero}
        />)
      }
    </div>
  )
}

export default Hero