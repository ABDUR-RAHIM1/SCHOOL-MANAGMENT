import React, { useContext, useEffect, useRef, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import img from '../../image/demo.jpg'
// Import Swiper styles
import 'swiper/css';
import "./Styles.css"
import "./Review.css"
import 'swiper/css/pagination';
import 'swiper/css/autoplay';

import { Autoplay, Pagination, Navigation } from 'swiper/modules';
import { GlobalContext } from '../../State/State';
export default function Review() {
    const { testimonial, setTestimonial } = useContext(GlobalContext)
    useEffect(() => {
        fetch("https://myschoool.onrender.com/api/settings/testimonial")
            .then(res => res.json())
            .then(data => {
                setTestimonial(data)
            })
    }, [setTestimonial])
    return (
        <div className="reviewContainer">
            <div className='review'>
                <h1 className='text-center my-4 color text-uppercase'>Parent's Perspective on Our School</h1>
                <Swiper
                    autoplay={{
                        delay: 3000,
                        disableOnInteraction: false,
                    }}
                    slidesPerView={3}
                    spaceBetween={30}
                    loop={true}
                    pagination={{
                        clickable: true,
                    }}
                    modules={[Pagination, Autoplay]}
                    className="mySwiper"
                    breakpoints={{
                        380: {
                            width: 336,
                            slidesPerView: 1,
                          },
                        480: {
                          width: 470,
                          slidesPerView: 2,
                        },
                        768: {
                          width: 768,
                          slidesPerView: 3,
                        },
                      }}
                >
                    {
                        testimonial.length > 0 && testimonial.map(testi => {
                            return (
                                <>
                                    <SwiperSlide className='slider mt-4' key={testi._id}>
                                        <img src={testi.image || img} alt="" />
                                        <div className="testHeader">
                                            <h6>{testi.name || "no name"}</h6>
                                            <p className='color'>{testi.profession}</p>
                                            <div className="testiBody">
                                                <p> <q> {testi.review}</q></p>
                                            </div>
                                        </div>
                                    </SwiperSlide>
                                </>
                            )
                        })
                    }
                </Swiper>
            </div>
        </div>
    );
}
