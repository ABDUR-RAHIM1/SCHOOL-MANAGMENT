import React, { useState } from 'react'
import "./Contact.css"
import img from "../../image/contact.png"
function Contact() {
    const [message , setMessage] = useState("")
    const [isLoading , setIsLoading]  = useState(false)
    const [contactText , setContactText]  =  useState({
         name : "",
         email :"",
         message : "",
    })
    const handleContactChange = (e)=>{
         setContactText({...contactText,[e.target.name]:e.target.value })
    }
    //  submit message 
    const handleSubmitContactMessage = (e)=>{
        e.preventDefault();
        setIsLoading(true)
        fetch("http://localhost:8000/api/contact",{
            method :"POST",
            headers :{
                "Content-type" :"application/json"
            },
            body : JSON.stringify(contactText)
        }).then( res  => res.json())
        .then(data => {
             setMessage(data.message)
            setIsLoading(false)
        })
    }
    return (
        <div id='contact' className='contact'>
         <h2 className='text-center my-4 color text-uppercase'>Contact With Us</h2>
            <div className="row mt-3">
                <div className="col-md-7">
                    <form onSubmit={handleSubmitContactMessage}>
                        <div className="row">
                            <div className="col-md-6">
                                <input onChange={handleContactChange} name='name' value={contactText.name} type="text" className='form-control' placeholder='Enter Your Name' required/>
                                <small className='text-muted'>Enter Your Name Here</small>
                            </div>
                            <div className="col-md-6">
                                <input onChange={handleContactChange} name='email' value={contactText.email}  type="text" className='form-control' placeholder='Enter Your Email' required />
                                <small className='text-muted'>Enter Your Email Here</small>
                            </div>
                            
                            <div className="col-12">
                                <textarea onChange={handleContactChange} name='message' value={contactText.message} className='form-control mt-4' placeholder='Message . . .' cols="10" rows="10" required/> 
                                <small className='text-muted'>Enter Your Message here</small>
                            </div>
                        </div>

                        <button type="submit" className="button-63 mt-3">
                             {
                                isLoading ? "Processing" : "Submit Message"
                             }
                        </button>
                        {
                            message && <h6 className='mt-3'>{message}</h6>
                        }
                    </form>
                </div>
                <div className="col-md-5">
                   <img className='w-100 contactImg' src={img} alt="" />
                </div>
            </div>
        </div>
    )
}

export default Contact