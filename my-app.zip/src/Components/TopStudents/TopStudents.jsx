import React, { useEffect, useState } from 'react' 
import TopStudent from './TopStudent';
import "./TopStudents.css"

function TopStudents() {
    const [topStudent, setTopStudent] = useState([])
    const [isLoading, setIsLoading] = useState(false)
 
    useEffect(() => {
        setIsLoading(true)
        const search = "";
        fetch("https://myschoool.onrender.com/api/student?search=" + search)
            .then(res => res.json())
            .then(data => {
                // find out top 10 student , roll is under 10
                const topSt = data.student.filter(tp => tp.roll <= 10)
                let top10 = null;
                if (topSt.length > 10) {
                    top10 = topSt.slice(-10)
                } else {
                    top10 = topSt
                };
                setTopStudent(top10)
                setIsLoading(false)
            })
    }, [])

    return (
        <>
            <h2 className='text-center color my-4  text-uppercase border-bottom p2'>Top Students</h2>
            <div className="top_students_container flex_box">
                {
                    topStudent && topStudent.map(tp => (
                        <TopStudent
                            key={tp._id}
                            topStudent={tp}
                        />
                    ))
                }
            </div>
        </>
    )
}

export default TopStudents