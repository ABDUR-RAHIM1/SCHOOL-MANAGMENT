import React, { useEffect } from 'react'
import 'aos/dist/aos.css';
import AOS from 'aos';
import {GiPrivateFirstClass} from "react-icons/gi"
import {MdAssessment} from "react-icons/md"
import {BiPaintRoll} from "react-icons/bi"
import demoImg from "../../image/demo.jpg"
function TopStudent(props) {
    const {name , photo , roll , session}  = props.topStudent; 
    useEffect(() => {
      AOS.init({ 
      });
    }, []);
  return (
    <div className='topStudent'data-aos="zoom-in-up">
         <img src={photo || demoImg} alt="" />
         <h6 className='color'>Name : {name}</h6>
         <p><BiPaintRoll className='topStIcon'/> Roll : {roll < 10 ? "0"+roll : roll}</p>
         <p><GiPrivateFirstClass className='topStIcon'/>  Class :  {props.topStudent.class < 10 ? "0"+props.topStudent.class : props.topStudent.class}</p>
         <p> <MdAssessment className='topStIcon'/> Session : {session}</p>
    </div>
  )
}

export default TopStudent