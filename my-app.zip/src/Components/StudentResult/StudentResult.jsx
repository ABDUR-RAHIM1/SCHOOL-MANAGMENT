import React, { useContext, useEffect, useState } from 'react' 
import { GlobalContext } from '../../State/State'
function StudentResult() {
    const {getDate} = useContext(GlobalContext)
    const [sort , setSort] = useState("")
    const [result, setResult] = useState([])
    const [message , setMessage] = useState("")
    const [isLoading, setIsLoading] = useState(false)
    const [call , setCall] = useState({})
    const [reseultValue, setResultValue] = useState({ studentName: "", group: "" });

    const handleResultChange = (e) => {
        const value = (e.target.value).toLowerCase()
        setResultValue({ ...reseultValue, [e.target.name]: value })
    }
    const handleResultSearch = (e) => {
        e.preventDefault()
        setIsLoading(true)
        setCall(reseultValue)
    }
    useEffect(()=>{ 
        fetch("https://myschoool.onrender.com/api/result/student?search="+sort, {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(reseultValue)
        }).then(res => res.json())
            .then(data => {
                setIsLoading(false)
                console.log(data)
                setMessage(data.message)
                setResult(data.uResult)

            })
    } ,[call, sort])

    //  total marks 
    let marks = 0
    if (result) {
        result.forEach(mark => {
            marks += mark.score
        })
    }
    const handleMonthChange = (e) => {
        const value = (e.target.value).toLowerCase()
        setSort(value)
    }
    return (
        <>
            <div className='my_form '>
                <form onSubmit={handleResultSearch} className='form-group form-control p-3'>
                    <input
                        type="text"
                        name="studentName"
                        placeholder='Student Name'
                        className='form-control mt-2'
                        required
                        onChange={handleResultChange}
                    />
                    <small className='text-muted'>Student Name</small>

                    <input
                        type="text"
                        name="group"
                        placeholder='Student Group'
                        className='form-control mt-2'
                        required
                        onChange={handleResultChange}
                    />
                    <small className='text-muted'>Student Group Name</small>

                    <button className='form-control fw-bold mt-3 btn-outline-info'>
                        {
                            isLoading ? "Searching . ." : "Search Now"
                        }
                    </button>
                </form>
            </div>

            {/*  show result   */}

            <div className= { result && result.length > 0 ? "showResult" :""}>
            <select onChange={handleMonthChange} >
                <option value="">Select Month</option>
                <option >January</option>
                <option>February</option>
                <option>March</option>
                <option>April</option>
                <option>May</option>
                <option>June</option>
                <option>July</option>
                <option>August</option>
                <option>September</option>
                <option>October</option>
                <option>November</option>
                <option>December</option>
            </select> 
            { message && <h2 className='text-warning my-3 text-center'>{message}</h2>}
                <table className='table table-striped table-responsive'>
                    {result && result.length > 0 ? <thead>
                        <tr>
                            <th>#No</th>
                            <th>Name</th>
                            <th>Class</th>
                            <th>Group</th>
                            <th>Month</th>
                            <th>Marks</th>
                            <th>Published</th>
                        </tr>
                    </thead>
                  : ""  }
                    <tbody>
                        {
                            result && result.map((res, index) => {
                                return (
                                    <tr>
                                        <td>{index + 1}</td>
                                        <td>{res.studentName}</td>
                                        <td>{res.category}</td>
                                        <td>{res.group}</td>
                                        <td>{res.examTime}</td>
                                        <td>{res.score}</td>
                                        <td>{getDate(res.dateOfPublication)}</td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                 { result && result.length > 0 ?  <tfoot>
                        <tr>
                            <th colSpan={4}></th>
                            <th>total Marks =</th>
                            <th>{marks}</th>
                            <th colSpan={2}></th>
                        </tr>
                    </tfoot>:""}
                </table>
            
            </div>

        </>
    )
}

export default StudentResult