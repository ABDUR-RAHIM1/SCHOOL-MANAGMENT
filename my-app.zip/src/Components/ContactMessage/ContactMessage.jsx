import React, { useEffect, useState } from 'react'
import "./ContactMessage.css"
import CmMessage from './CmMessage';
function ContactMessage() {
  const [contactMessage, setContactMessage] = useState([]);
  const [message, setMessage] = useState("")
  const [isDelete, setIsDelete] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    message ? setIsLoading(false) : setIsLoading(true)
    fetch("https://myschoool.onrender.com/api/contact")
      .then(res => res.json())
      .then(data => {
        setIsLoading(false)
        setContactMessage(data)
      })
  }, [isDelete]);

  const handleContactDelete = (id) => {
    fetch(`https://myschoool.onrender.com/api/contact/${id}`, {
      method: "DELETE",
    }).then(res => res.json())
      .then(data => {
        setMessage(data.message)
        setIsDelete(!isDelete)
      })
  }
  return (
    <>
      <h2 className='text-center my-4 color'>Contact Message</h2>
      <div className="contactMessage flex_box">
        {
          isLoading && <h6>Waiting . . .</h6>
        }
        {
          contactMessage && contactMessage.slice().reverse().map(cm => (
            <CmMessage
              key={cm._id}
              contact={cm}
              handleContactDelete={handleContactDelete}
            />
          ))
        }
        {
          contactMessage.length <= 0 && <h2 className=' text-danger border my-4'>Contact Message Box is Empty</h2>
        }
      </div>
    </>
  )
}

export default ContactMessage