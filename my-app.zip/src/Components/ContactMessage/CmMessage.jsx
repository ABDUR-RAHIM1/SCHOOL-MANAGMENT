import { useEffect, useState } from "react";
import { AiFillDelete } from "react-icons/ai"
import { FcViewDetails } from "react-icons/fc"
function CmMessage(props) {
    const { _id, name, email, message } = props.contact;
    const [show, setShow] = useState(false)
 
    return (
        <div className='cmMessage'>
            <h6>Name : {name}</h6>
            <p>Email : {email}</p>
            <p>Message : {show ? message : message.slice(0, 100)}</p>
            <div className="iconBtn flex_box">
                {message.length > 100 && <FcViewDetails onClick={() => setShow(!show)} className="contactIcon" />}
                <AiFillDelete onClick={() => props.handleContactDelete(_id)} className="contactIcon" />

            </div>
        </div>
    )
}

export default CmMessage