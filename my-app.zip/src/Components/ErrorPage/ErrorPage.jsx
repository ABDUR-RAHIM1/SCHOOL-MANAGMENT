import React from 'react'

function ErrorPage() {
  return (
    <div className='ErrorPage'>
         <h1 className='text-danger'>
            Opss ! Page not found
         </h1>
    </div>
  )
}

export default ErrorPage