import React, { useState } from 'react'
import Spinner from '../Spinner/Spinner'
import "./GiveReview.css"
import Notification from '../../Utilities/Notification'
function GiveReview() {
  const [message, setMessage] = useState("")
  const [loading, setLoading] = useState(false)
  const [imageLoading, setImgLoading] = useState(false)
  const [testimonialText, setTestimonialText] = useState({
    name: "",
    profession: "",
    review: "",
    image: ""
  })
  const handellogoChange = async (e) => {
    setImgLoading(true)
    const file = e.target.files[0]
    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", "demo-image");
    formData.append("cloud_name", "dsrkrb3jy");
    const res = await fetch(
      "https://api.cloudinary.com/v1_1/dsrkrb3jy/image/upload",
      {
        method: "POST",
        body: formData,
      })
    const data = await res.json()
    setTestimonialText((preTest) => ({
      ...preTest,
      image: data.secure_url
    }))

    setImgLoading(false)
  };

  const handleTesti = (e) => {
    setTestimonialText({ ...testimonialText, [e.target.name]: e.target.value })
  }
  const handleTestimonialAdd = (e) => { 
    setLoading(true)
    e.preventDefault()
    fetch("https://myschoool.onrender.com/api/settings/testimonial", {
      method: "POST",
      headers: {
        "Content-type": "application/json"
      },
      body: JSON.stringify(testimonialText)
    }).then(res => res.json()) 
      .then(data => {
        console.log(data)
        setLoading(false)
        data.error ? setMessage(data.error) : setMessage(data.message)
      }).catch(err => {
        setMessage("failed to fatch data")
      })
  }

  if (message) {
    setTimeout(() => {
      setMessage("")
    }, 2000);
  } 
  return (
    <div className='giveReviewContainer'>
      {message && <Notification message={message} />}
      <form className='form-control p-3' onSubmit={handleTestimonialAdd}>
        <h4 className='p-2 color'>Give a review</h4>
        <input onChange={handleTesti}
          className='form-control mt-3'
          name='name'
          type="text"
          value={testimonialText.name}
          required
          placeholder='Name'
        />
        <small className='text-muted'>Write Your Name</small>
        <input onChange={handleTesti}
          className='form-control mt-3'
          name='profession'
          type="text"
          value={testimonialText.profession}
          required
          placeholder='profession'
        />
        <small className='text-muted'>Write Your profession</small>
        <textarea onChange={handleTesti} 
          className='form-control mt-3 textArea'
          name='review'
          type="text"
          value={testimonialText.review}
          required
          placeholder='minimum 100 character'
        />
        <small className='text-muted'>Write Review minimum 100 character</small>
        {!imageLoading ?
          <input onChange={handellogoChange} name='heroImage' className='form-control mt-3' type="file" /> :
          <div className='mt-4 laodingDiv'> <Spinner /> <span>Image Uploading . . . </span></div>
        }
        <button disabled={imageLoading} className='button-63 my-3'>Submit Review</button>
        {
          loading && <Spinner />
        }
      </form>

    </div>
  )
}

export default GiveReview