import React, { useEffect } from 'react'
import AOS from 'aos';
import 'aos/dist/aos.css';
import aboutPhoto from "../../image/about.png"
import GiveReview from '../GiveReview/GiveReview'
import "./About.css"
function About() {
    //  animation
    useEffect(() => {
        AOS.init({ 
        });
      }, []);
    return (
        <div className='about-page'>
            <h2 className='text-center color mb-4 border-bottom p-2'>ABOUT US</h2>
            <div className="row mt-4">

                <div className="col-md-6 text-center" data-aos="fade-up">
                    <div className="about-img ">
                        <img className='w-100' src={aboutPhoto} alt="" />
                    </div>
                </div>
                <div className="col-md-6"data-aos="fade-left">
                    <div className="about-text" >
                        <h3 className='color'>Welcome to our school- Where Learning Meets Excellence!</h3>
                        <p>we believe that education is the key to unlocking the full potential within every child. Since our establishment in [year], we have been committed to providing a nurturing and inspiring environment that fosters academic growth, character development, and lifelong learning.</p>
                        <p>
                            <span className='about_headline'>Our Vision:</span>
                            At the heart of our vision is the aim to create well-rounded individuals who are equipped to face the challenges of the ever-changing world. We envision a community of learners who are not only academically proficient but also compassionate, creative, and confident individuals.
                        </p>

                    </div>
                </div>
            </div>
            <div className="aboutMain">
                <div className="aboutText" data-aos="fade-right">
                    <p className='top'><span className='about_headline'>Our Mission:</span>
                        Our mission is to provide a dynamic and holistic education that empowers students to excel academically, emotionally, and socially. We strive to cultivate a passion for learning, critical thinking, and problem-solving skills in our students. Through a diverse range of experiences and extracurricular activities, we encourage them to explore their interests and talents.</p>
                    <p ><span className="about_headline ">Our Approach:</span> we embrace an innovative and student-centric approach to education. Our dedicated team of educators is committed to recognizing the unique learning styles and abilities of each student. We foster an inclusive and supportive environment, allowing every child to thrive and reach their highest potential </p>
                </div>
                <div className="aboutText"data-aos="fade-left">
                    <p className='top'><span className='about_headline'>Academic Excellence:</span>
                        We uphold high academic standards and continuously enhance our curriculum to ensure it remains relevant to the evolving needs of the global community. Our classrooms are equipped with state-of-the-art technology and learning resources that enable interactive and engaging learning experiences.</p>
                    <p><span className='about_headline'>Character Development:</span>
                        We understand the importance of character development in shaping responsible and ethical citizens. Through various character-building programs and initiatives, we instill values such as integrity, respect, empathy, and perseverance in our students.</p>

                </div>
                <div className="aboutText" data-aos="fade-right">
                    <p className='top'>
                        <span className='about_headline'> Community and Parent Engagement:</span>
                        At [School Name], we believe that education is a collaborative effort between the school, parents, and the community. We encourage active participation from parents and guardians in their child's educational journey. Regular parent-teacher interactions, workshops, and events strengthen this partnership, creating a cohesive support system for our students.
                    </p>
                    <p>

                        <span className='about_headline'> A Vibrant Learning Environment:</span>
                        Our campus provides a safe and vibrant learning environment where students feel motivated to explore, create, and take risks. We offer a wide range of extracurricular activities, including sports, arts, clubs, and community service opportunities, to nurture well-rounded individuals with diverse interests.
                    </p>
                </div>
                <div className="aboutTextFooter">
                    <p className='fw-bold color'>
                        Thank you for considering our school as the foundation for your child's bright future. We look forward to welcoming you into our family.

                        Together, let's pave the way for a lifetime of learning and excellence!
                    </p>
                </div>
            </div>

            <GiveReview />
        </div>
    )
}

export default About