import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Admins from '../Admins/Admins' 
import StudentProfile from '../../StudentProfile/StudentProfile';
function AdminHome() {
  const [showCompo, setShowCompo] = useState(true)
  return (
    <>

      <div className='adminHomeContainer'> 
        <div className="admin-home-button flex_box">
          <button onClick={() => setShowCompo(!showCompo)} className="button-63 my-4">
            {
              showCompo ? "See Users" : "See Admins"
            }
          </button>
          <Link to="/auth" state="admin-create">
            <button className="button-63 my-4">Create Admin</button>
          </Link>
        </div>

        {showCompo ? <Admins /> :
          <StudentProfile />}
      </div>
    </>
  )
}

export default AdminHome