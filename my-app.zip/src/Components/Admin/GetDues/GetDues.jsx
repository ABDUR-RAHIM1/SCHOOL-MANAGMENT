import React, { useContext, useEffect, useState } from 'react'
import { GlobalContext } from '../../../State/State'
import Due from './Due'
import Loading from '../../Loading/Loading'
import Checkbox from '../../Checkbox/Checkbox'

function GetDues() {
    const [check , setChack] = useState(false)
    const [search, setSearch] = useState("")
    const [message, setMessage] = useState("")
    const [loading, setLoading] = useState(false)
    const [isDelete, setIsDelete] = useState(false)
    const { due, setDue } = useContext(GlobalContext)
    
    const handleDeleteDue = (id) => {
        setIsDelete(true);
        fetch(`https://myschoool.onrender.com/api/due/${id}`, {
            method: "DELETE",
        }).then(res => res.json())
            .then(data => {
                console.log(data)
                setMessage(data.message)
                setIsDelete(false);
            })
    }
    useEffect(() => {
        if (message || search) {
            setLoading(false)
        } else {
            setLoading(true)
        }
        fetch("https://myschoool.onrender.com/api/due?search=" + search)
            .then(res => res.json())
            .then(data => {
                console.log(data)
                setDue(data.dueAmmount)
                setLoading(false)
            })
    }, [isDelete, search]);


    const handleSearch = (e) => {
        const value = (e.target.value).toLowerCase()
        setSearch(value)
    }

    if (loading) {
        return <Loading />
    } 
    let totolDue = 0;
    if (due) {
        due.forEach(element => {
             console.log(element.itemPrice)
             totolDue += element.itemPrice;
        });
    }
    return (
        <div className='getDuesContainer'>
            <div className="checbox-container">
                <Checkbox handleCheck={()=>setChack(!check)} />
            </div>
            <div className="searchBar">
                <input onChange={handleSearch} placeholder='find due' type="text" className='form-control my-3' />
            </div>
            
            <h2 className='text-center my-3 color'>Dues</h2>
            {
                due.length <= 0 && <h2 className='mt-4'>Opps ! <span className='text-warning '>{search}</span> Not found</h2>
            }
            <table className='table table-hover table-responsive'>
                {due.length > 0 && <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Class  </th>
                        <th>Items</th> 
                        <th>Quantity</th>
                        <th>Total Due</th>
                        <th>Date</th>
                       {check && <th>Edit/Delete</th>}
                    </tr>
                </thead>}
                {
                    Object.keys(due).length !== 0 && due.map(due => <Due
                        key={due._id}
                        due={due}
                        check={check}
                        isDelete={isDelete}
                        handleDeleteDue={handleDeleteDue}
                    />)

                }
            { due && due.length > 0 ?   <tfoot>
                     <tr> 
                        <th colSpan={3}></th>
                     <th className='text-danger'>Total : </th>
                     <th className='text-danger'>{totolDue}Tk</th>
                     <th colSpan={2}></th>
                     </tr>
                </tfoot>: ""}
            </table>

        </div>
    )
}

export default GetDues