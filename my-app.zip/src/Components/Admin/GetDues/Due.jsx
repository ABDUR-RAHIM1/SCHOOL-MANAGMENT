import React, { useContext } from 'react'
import { BiEdit } from "react-icons/bi"
import { AiFillDelete } from "react-icons/ai"
import "./GetDues.css"
import { GlobalContext } from '../../../State/State'
import AddDue from '../AddDue/AddDue'
function Due(props) {
    const { _id, studentName, studentClass, itemName, itemPrice, itemQuntity, dueAt } = props.due
     const {getDate} = useContext(GlobalContext)
    const { setComponent } = useContext(GlobalContext)
    const handleEditDue = (id) => {
        if (id) return setComponent(<AddDue
            dueId={id}
            dueInfo={props.due}
        />)
    }
     
    

    const result = getDate(dueAt)
    console.log(result)
    return (
        <>

            <tbody>
                <tr>
                    <td>{studentName}</td>
                    <td>{studentClass < 10 ? "0"+studentClass : studentClass}</td>
                    <td>{itemName.map(itName => itName)}</td> 
                    <td>{itemQuntity.map(itQn => itQn)}</td>
                    <td>{itemPrice} TK</td> 
                    <td>{getDate(dueAt)}</td> 
                    {props.check && <td className='flex_box'>
                        <BiEdit onClick={() => handleEditDue(_id)} className='stAdminIcon resultBtn' />
                        <AiFillDelete  onClick={() => props.handleDeleteDue(_id)} className={props.isDelete ?'stAdminIcon resultBtn text-muted'  : 'stAdminIcon resultBtn'} />
                    </td>} 
                </tr>
            </tbody>

        </>
    )
}

export default Due