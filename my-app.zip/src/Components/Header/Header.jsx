import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { BsFillKeyFill } from "react-icons/bs"
import "./Header.css"
import { Link, useLocation } from 'react-router-dom';
import { useContext, useEffect } from 'react';
import { GlobalContext } from '../../State/State';

function Header() {
  const { getLogo, setGetLogo, isDelete } = useContext(GlobalContext)
  const location = useLocation().pathname
  const logos = getLogo[getLogo.length - 1]

  console.log(location)

  useEffect(() => {
    fetch("https://myschoool.onrender.com/api/settings/logo")
      .then(res => res.json())
      .then(data => {
        setGetLogo(data)
      })
  }, [setGetLogo, isDelete])
  return (
    <Navbar expand="lg" className="headerConatiner">
      <Navbar.Brand as={Link} to="/" className='logo'>
        <img src={logos ? logos.logo : getLogo} alt="" />
      </Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className='me-auto'>
          <Nav.Link
            className={location === "/" ? "navItem nav_active" : "navItem"}
            as={Link}
            to="/"
          >Home
          </Nav.Link>
          {location === "/" && <Nav.Link className="navItem contactItem"
            href="#contact"
          >Contact
          </Nav.Link>}
          <Nav.Link className={location === "/about-us" ? "navItem nav_active" : "navItem"}
            as={Link}
            to="/about-us"
          >about us
          </Nav.Link>


          <Nav.Link className={location === "/auth" ? "navItem nav_active" : "navItem"} as={Link}
            to="/auth" >
            {/* <BsFillKeyFill className='login_icon' /> */}
            <button className='btn btn-primary'>SIGN-IN</button>
          </Nav.Link>

        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
}

export default Header;