import { useContext, useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Spinner from "../../Components/Spinner/Spinner"
import FormInput from '../../Utilities/FormInput';
import { GlobalContext } from '../../State/State';

function ResetPassword(props) {     //  from admin login component
  const [show, setShow] = useState(true);
  const handleClose = () => {
    setShow(false)
    props.show(false)
  };

  const { loginInfo, setLoginInfo } = useContext(GlobalContext);

  const handleResetChange = (e) => {
    const value = (e.target.value).toLowerCase();
    setLoginInfo({ ...loginInfo, [e.target.name]: value });
  };

  return (
    <>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Reset Password</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={props.handleRsetSubmit}>
            <FormInput
              type="text"
              placeholder="Username"
              name="name"
              value={loginInfo.name}
              required="required"
              handleChange={handleResetChange}
            />
            <FormInput
              type="email"
              placeholder="Email"
              name="email"
              value={loginInfo.email}
              required="required"
              handleChange={handleResetChange}
            />
            <FormInput
              type="password"
              placeholder="New password"
              name="password"
              required="required"
              value={loginInfo.password}
              handleChange={handleResetChange}
            />
            <button className='button-63 my-3'>
              {
                props.resetLoading ? "Checking" : "Reset Now"
              }
            </button>
          </form>
          {
            
              props.message.includes("valid") ? <h6 className='text-center text-danger my-3'>{props.message}</h6> :
                <h6 className='text-center text-success my-3'>{props.message}</h6>
            
          }

        </Modal.Body>
      </Modal>
    </>
  );
}

export default ResetPassword;
